package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.ChapterItem
import com.example.model.ExamCategoryId
import com.example.viewmodel.MainViewModel

@Composable
fun SyllabusTrackerScreen(
    viewModel: MainViewModel,
    onOpenExamSelector: () -> Unit
) {
    val chapters by viewModel.chapters.collectAsState()
    val selectedExams by viewModel.selectedExams.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var selectedCategoryFilter by remember { mutableStateOf<String>("ALL") }
    var selectedSubjectFilter by remember { mutableStateOf("ALL") }
    var statusFilter by remember { mutableStateOf("ALL") }

    // Modals
    var editingChapter by remember { mutableStateOf<ChapterItem?>(null) }
    var showAddModal by remember { mutableStateOf(false) }

    // Chapters filtered by selected exams first
    val activeExamNames = selectedExams.map { it.name }.toSet()
    val userRelevantChapters = remember(chapters, selectedExams) {
        chapters.filter { activeExamNames.contains(it.examCategory) }
    }

    // Available subjects in active chapters
    val availableSubjects = remember(userRelevantChapters) {
        listOf("ALL") + userRelevantChapters.map { it.subject }.distinct().sorted()
    }

    // Filtered list
    val displayedChapters = remember(userRelevantChapters, searchQuery, selectedCategoryFilter, selectedSubjectFilter, statusFilter) {
        userRelevantChapters.filter { ch ->
            // Category filter
            if (selectedCategoryFilter != "ALL" && ch.examCategory != selectedCategoryFilter) return@filter false

            // Subject filter
            if (selectedSubjectFilter != "ALL" && ch.subject != selectedSubjectFilter) return@filter false

            // Search query
            if (searchQuery.isNotBlank() && !ch.name.contains(searchQuery, ignoreCase = true)) return@filter false

            // Status filter
            when (statusFilter) {
                "DONE" -> ch.isTheoryDone
                "PENDING" -> !ch.isTheoryDone
                "NO_PYQ" -> ch.pyqsCount == 0
                else -> true
            }
        }
    }

    val totalActive = userRelevantChapters.size
    val totalDone = userRelevantChapters.count { it.isTheoryDone }
    val totalPyqs = userRelevantChapters.sumOf { it.pyqsCount }
    val completionPct = if (totalActive > 0) ((totalDone.toFloat() / totalActive) * 100).toInt() else 0

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        // Top Header Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Syllabus & PYQ Tracker",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "$completionPct% Completed • $totalPyqs PYQs Solved",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(
                    onClick = { showAddModal = true },
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add Chapter", fontSize = 11.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Chapter ka naam search karein...", fontSize = 12.sp) },
            leadingIcon = {
                Icon(imageVector = Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp))
            },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { searchQuery = "" }) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Clear", modifier = Modifier.size(16.dp))
                    }
                }
            },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp)
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Category Filter Tabs (Selected Exams)
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            item {
                FilterChip(
                    selected = selectedCategoryFilter == "ALL",
                    onClick = { selectedCategoryFilter = "ALL" },
                    label = { Text("All Selected (${selectedExams.size})", fontSize = 11.sp) }
                )
            }
            items(selectedExams.toList()) { exam ->
                FilterChip(
                    selected = selectedCategoryFilter == exam.name,
                    onClick = { selectedCategoryFilter = exam.name },
                    label = { Text(exam.shortName, fontSize = 11.sp) }
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Subject Filter Tabs
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(availableSubjects) { sub ->
                FilterChip(
                    selected = selectedSubjectFilter == sub,
                    onClick = { selectedSubjectFilter = sub },
                    label = { Text(sub, fontSize = 11.sp) }
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Chapters List
        if (displayedChapters.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.MenuBook,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.outline,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Koi chapter nahi mila.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    TextButton(onClick = { onOpenExamSelector() }) {
                        Text("Exam selection badlein")
                    }
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                items(displayedChapters) { chapter ->
                    ChapterListItem(
                        chapter = chapter,
                        onToggleTheory = { viewModel.toggleTheoryDone(chapter.id) },
                        onAdjustPyq = { delta -> viewModel.adjustPyqs(chapter.id, delta) },
                        onCycleRevision = { viewModel.cycleRevision(chapter.id) },
                        onClick = { editingChapter = chapter }
                    )
                }
            }
        }
    }

    // Edit Chapter Dialog
    editingChapter?.let { ch ->
        ChapterDetailDialog(
            chapter = ch,
            onSave = { updated ->
                viewModel.updateChapter(updated)
                editingChapter = null
            },
            onDelete = {
                viewModel.deleteChapter(ch.id)
                editingChapter = null
            },
            onDismiss = { editingChapter = null }
        )
    }

    // Add Custom Chapter Dialog
    if (showAddModal) {
        AddChapterDialog(
            selectedExams = selectedExams,
            onAdd = { name, cls, sub, cat ->
                viewModel.addCustomChapter(name, cls, sub, cat)
                showAddModal = false
            },
            onDismiss = { showAddModal = false }
        )
    }
}

@Composable
fun ChapterListItem(
    chapter: ChapterItem,
    onToggleTheory: () -> Unit,
    onAdjustPyq: (Int) -> Unit,
    onCycleRevision: () -> Unit,
    onClick: () -> Unit
) {
    val examCategory = ExamCategoryId.fromId(chapter.examCategory)

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (chapter.isTheoryDone) MaterialTheme.colorScheme.primary.copy(alpha = 0.4f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Left: Checkbox + Chapter info
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                IconButton(
                    onClick = onToggleTheory,
                    modifier = Modifier
                        .size(32.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            if (chapter.isTheoryDone) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.surfaceVariant
                        )
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "Theory Done",
                        tint = if (chapter.isTheoryDone) Color.White else MaterialTheme.colorScheme.outline,
                        modifier = Modifier.size(16.dp)
                    )
                }

                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = Color(examCategory.badgeColorHex).copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = chapter.subject,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(examCategory.badgeColorHex),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }

                        if (chapter.classLevel.isNotBlank() && chapter.classLevel != "All") {
                            Text(
                                text = "Class ${chapter.classLevel}",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    Text(
                        text = chapter.name,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = if (chapter.isTheoryDone) FontWeight.Medium else FontWeight.Normal,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            // Right: PYQ counter & Revision Pill
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // PYQs Box
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "PYQ: ${chapter.pyqsCount}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFF59E0B)
                        )
                        IconButton(
                            onClick = { onAdjustPyq(10) },
                            modifier = Modifier.size(18.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = "+10", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(12.dp))
                        }
                    }
                }

                // Revision Pill
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (chapter.revisionCount > 0) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.clickable { onCycleRevision() }
                ) {
                    Text(
                        text = "Rev: ${chapter.revisionCount}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (chapter.revisionCount > 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun ChapterDetailDialog(
    chapter: ChapterItem,
    onSave: (ChapterItem) -> Unit,
    onDelete: () -> Unit,
    onDismiss: () -> Unit
) {
    var isTheory by remember { mutableStateOf(chapter.isTheoryDone) }
    var isMock by remember { mutableStateOf(chapter.hasAttendedMock) }
    var pyqs by remember { mutableStateOf(chapter.pyqsCount.toString()) }
    var revisions by remember { mutableStateOf(chapter.revisionCount) }
    var notes by remember { mutableStateOf(chapter.notes) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = chapter.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${chapter.subject} • Class ${chapter.classLevel}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Theory Complete:")
                    Switch(checked = isTheory, onCheckedChange = { isTheory = it })
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Mock Test Solved:")
                    Switch(checked = isMock, onCheckedChange = { isMock = it })
                }

                OutlinedTextField(
                    value = pyqs,
                    onValueChange = { pyqs = it },
                    label = { Text("PYQs Solved Count") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Revisions Count: $revisions")
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Button(
                            onClick = { revisions = (revisions - 1).coerceAtLeast(0) },
                            contentPadding = PaddingValues(horizontal = 8.dp)
                        ) { Text("-") }
                        Button(
                            onClick = { revisions += 1 },
                            contentPadding = PaddingValues(horizontal = 8.dp)
                        ) { Text("+") }
                    }
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Mock Score & Mistake Notes") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 3
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    TextButton(onClick = onDelete) {
                        Text("Delete", color = MaterialTheme.colorScheme.error)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = onDismiss) { Text("Cancel") }
                        Button(onClick = {
                            val pyqInt = pyqs.toIntOrNull() ?: 0
                            onSave(
                                chapter.copy(
                                    isTheoryDone = isTheory,
                                    hasAttendedMock = isMock,
                                    pyqsCount = pyqInt,
                                    revisionCount = revisions,
                                    notes = notes
                                )
                            )
                        }) {
                            Text("Save")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AddChapterDialog(
    selectedExams: Set<ExamCategoryId>,
    onAdd: (name: String, classLevel: String, subject: String, category: ExamCategoryId) -> Unit,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf("") }
    var classLevel by remember { mutableStateOf("12") }
    var subject by remember { mutableStateOf("Physics") }
    var selectedCat by remember { mutableStateOf(selectedExams.firstOrNull() ?: ExamCategoryId.NEET_UG) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Naya Chapter Jodein",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Chapter Ka Naam") },
                    placeholder = { Text("e.g. Semiconductors / Mole Concept") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = subject,
                    onValueChange = { subject = it },
                    label = { Text("Subject") },
                    placeholder = { Text("Physics / Chemistry / Maths / GS") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = classLevel,
                    onValueChange = { classLevel = it },
                    label = { Text("Class (10, 11, 12, All)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(onClick = onDismiss) { Text("Cancel") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (name.isNotBlank()) {
                                onAdd(name, classLevel, subject, selectedCat)
                            }
                        }
                    ) {
                        Text("Add")
                    }
                }
            }
        }
    }
}
