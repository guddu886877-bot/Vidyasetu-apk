package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Launch
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CoachingPlatform
import com.example.model.ExamCategoryId
import com.example.viewmodel.MainViewModel

@Composable
fun CoachingHubScreen(
    viewModel: MainViewModel
) {
    val context = LocalContext.current
    val platforms = viewModel.coachingPlatforms

    var selectedFilter by remember { mutableStateOf("ALL") }

    val filteredPlatforms = remember(platforms, selectedFilter) {
        when (selectedFilter) {
            "BOARDS" -> platforms.filter { p ->
                p.categoriesCovered.contains(ExamCategoryId.CLASS_10) || p.categoriesCovered.contains(ExamCategoryId.CLASS_12)
            }
            "JEE_NEET" -> platforms.filter { p ->
                p.categoriesCovered.contains(ExamCategoryId.JEE_MAIN_ADV) || p.categoriesCovered.contains(ExamCategoryId.NEET_UG)
            }
            "GOVT" -> platforms.filter { p ->
                p.categoriesCovered.any { it.name.startsWith("GOVT_") }
            }
            else -> platforms
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        // Top Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.CastForEducation,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
            }
            Column {
                Text(
                    text = "Coaching Apps Hub",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "PW, Motion, Target Board, KGS, Allen - Sabhi yahan!",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Filter Chips
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            item {
                FilterChip(
                    selected = selectedFilter == "ALL",
                    onClick = { selectedFilter = "ALL" },
                    label = { Text("Sabhi Platforms (${platforms.size})") }
                )
            }
            item {
                FilterChip(
                    selected = selectedFilter == "JEE_NEET",
                    onClick = { selectedFilter = "JEE_NEET" },
                    label = { Text("JEE / NEET") }
                )
            }
            item {
                FilterChip(
                    selected = selectedFilter == "BOARDS",
                    onClick = { selectedFilter = "BOARDS" },
                    label = { Text("10th & 12th Boards") }
                )
            }
            item {
                FilterChip(
                    selected = selectedFilter == "GOVT",
                    onClick = { selectedFilter = "GOVT" },
                    label = { Text("Govt Exams (KGS/SSC/UPSC)") }
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Coaching Platforms List
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(filteredPlatforms) { platform ->
                CoachingPlatformCard(
                    platform = platform,
                    context = context,
                    onOpenInAppStudy = {
                        viewModel.openWebViewer(platform.webUrl, platform.name)
                    }
                )
            }
        }
    }
}

@Composable
fun CoachingPlatformCard(
    platform: CoachingPlatform,
    context: Context,
    onOpenInAppStudy: () -> Unit
) {
    val pm = context.packageManager
    val isAppInstalled = remember(platform.packageName) {
        val intent1 = pm.getLaunchIntentForPackage(platform.packageName)
        val intent2 = platform.altPackageName?.let { pm.getLaunchIntentForPackage(it) }
        intent1 != null || intent2 != null
    }

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.2.dp, Color(platform.brandColorHex).copy(alpha = 0.35f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header Row: Logo, Name, Founder, Installed Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(platform.brandColorHex)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = platform.name.split(" ").mapNotNull { it.firstOrNull()?.toString() }.take(2).joinToString(""),
                            color = Color.White,
                            fontWeight = FontWeight.Black,
                            fontSize = 18.sp
                        )
                    }
                    Column {
                        Text(
                            text = platform.name,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Lead by ${platform.founderOrBrand}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // App Installed Badge or Store Pill
                if (isAppInstalled) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFF10B981).copy(alpha = 0.15f)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(12.dp))
                            Text("Installed", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF10B981))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Tagline
            Text(
                text = "\"${platform.tagline}\"",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Popular Batches
            Text(
                text = "POPULAR BATCHES & COURSES:",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = Color(platform.brandColorHex)
            )
            Spacer(modifier = Modifier.height(4.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(platform.popularBatches) { batch ->
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Text(
                            text = batch,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Action Buttons Row: Open App, In-App Portal, YouTube
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Primary action: Launch app or in-app study
                Button(
                    onClick = {
                        val launchIntent = pm.getLaunchIntentForPackage(platform.packageName)
                            ?: (platform.altPackageName?.let { pm.getLaunchIntentForPackage(it) })
                        if (launchIntent != null) {
                            context.startActivity(launchIntent)
                        } else {
                            onOpenInAppStudy()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(platform.brandColorHex)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = if (isAppInstalled) Icons.AutoMirrored.Filled.Launch else Icons.AutoMirrored.Filled.MenuBook,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isAppInstalled) "App Kholo" else "Yahi Padhein",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }

                // Free YouTube lectures
                OutlinedButton(
                    onClick = {
                        try {
                            val ytIntent = Intent(Intent.ACTION_VIEW, Uri.parse(platform.youtubeChannelUrl))
                            context.startActivity(ytIntent)
                        } catch (e: Exception) {
                            Toast.makeText(context, "Could not open YouTube", Toast.LENGTH_SHORT).show()
                        }
                    },
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp)
                ) {
                    Icon(imageVector = Icons.Default.SmartDisplay, contentDescription = "YouTube", tint = Color(0xFFEF4444), modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("YouTube", fontSize = 11.sp)
                }

                // Play Store install option if not installed
                if (!isAppInstalled) {
                    OutlinedButton(
                        onClick = {
                            try {
                                val storeIntent = Intent(Intent.ACTION_VIEW, Uri.parse(platform.playStoreUrl))
                                context.startActivity(storeIntent)
                            } catch (e: Exception) {
                                Toast.makeText(context, "Cannot open Play Store", Toast.LENGTH_SHORT).show()
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp)
                    ) {
                        Icon(imageVector = Icons.Default.GetApp, contentDescription = "Install", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Install", fontSize = 11.sp)
                    }
                }
            }
        }
    }
}
