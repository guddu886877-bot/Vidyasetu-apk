package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppRepository
import com.example.data.DefaultData
import com.example.data.GeminiAiService
import com.example.model.AiMessage
import com.example.model.ChapterItem
import com.example.model.CoachingPlatform
import com.example.model.ExamCategoryId
import com.example.model.FormulaNote
import com.example.model.StudyTask
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class AppNavScreen {
    HOME,
    COACHING_HUB,
    AI_DOUBT_SOLVER,
    SYLLABUS_TRACKER,
    FORMULAS_DIARY,
    WEB_VIEWER
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = AppRepository(application.applicationContext)

    // Navigation
    private val _currentScreen = MutableStateFlow(AppNavScreen.HOME)
    val currentScreen: StateFlow<AppNavScreen> = _currentScreen.asStateFlow()

    private val _webViewerUrl = MutableStateFlow("https://www.pw.live")
    val webViewerUrl: StateFlow<String> = _webViewerUrl.asStateFlow()

    private val _webViewerTitle = MutableStateFlow("Physics Wallah")
    val webViewerTitle: StateFlow<String> = _webViewerTitle.asStateFlow()

    // Multi-select Active Exams (10th, 11th, 12th, JEE, NEET, Govt Exams)
    private val _selectedExams = MutableStateFlow<Set<ExamCategoryId>>(repository.getSelectedExams())
    val selectedExams: StateFlow<Set<ExamCategoryId>> = _selectedExams.asStateFlow()

    // Chapters
    private val _chapters = MutableStateFlow<List<ChapterItem>>(repository.getChapters())
    val chapters: StateFlow<List<ChapterItem>> = _chapters.asStateFlow()

    // Tasks / To-Do
    private val _tasks = MutableStateFlow<List<StudyTask>>(repository.getTasks())
    val tasks: StateFlow<List<StudyTask>> = _tasks.asStateFlow()

    // Formula Notes
    private val _notes = MutableStateFlow<List<FormulaNote>>(repository.getNotes())
    val notes: StateFlow<List<FormulaNote>> = _notes.asStateFlow()

    // Coaching Platforms
    val coachingPlatforms: List<CoachingPlatform> = DefaultData.coachingPlatforms

    // AI Doubt Solver Messages
    private val _aiMessages = MutableStateFlow<List<AiMessage>>(
        listOf(
            AiMessage(
                id = 1L,
                role = "model",
                text = "Namaste! Mai hoon aapka **VidyaSetu AI Guru** 🚀\n\nAap Class 10th se 12th, JEE, NEET ya kisi bhi Government Exam (SSC, UPSC, Railway, Bank, Defence) se juda koi bhi sawal poochh sakte hain. Step-by-step formula, concept ya numericals turant solve honge!",
                timestamp = System.currentTimeMillis()
            )
        )
    )
    val aiMessages: StateFlow<List<AiMessage>> = _aiMessages.asStateFlow()

    private val _isAiThinking = MutableStateFlow(false)
    val isAiThinking: StateFlow<Boolean> = _isAiThinking.asStateFlow()

    // Pomodoro Timer
    private val _timerSeconds = MutableStateFlow(25 * 60)
    val timerSeconds: StateFlow<Int> = _timerSeconds.asStateFlow()

    private val _initialTimerSeconds = MutableStateFlow(25 * 60)
    val initialTimerSeconds: StateFlow<Int> = _initialTimerSeconds.asStateFlow()

    private val _isTimerRunning = MutableStateFlow(false)
    val isTimerRunning: StateFlow<Boolean> = _isTimerRunning.asStateFlow()

    private val _totalStudyMinutes = MutableStateFlow(repository.getTotalStudyMinutes())
    val totalStudyMinutes: StateFlow<Int> = _totalStudyMinutes.asStateFlow()

    private var timerJob: Job? = null

    // Motivational Shayari
    private val _shayariIndex = MutableStateFlow(0)
    val shayariIndex: StateFlow<Int> = _shayariIndex.asStateFlow()

    init {
        // Auto-rotate shayari every 12 seconds
        viewModelScope.launch {
            while (true) {
                delay(12000)
                nextShayari()
            }
        }
    }

    // Navigation functions
    fun navigateTo(screen: AppNavScreen) {
        _currentScreen.value = screen
    }

    fun openWebViewer(url: String, title: String) {
        _webViewerUrl.value = url
        _webViewerTitle.value = title
        _currentScreen.value = AppNavScreen.WEB_VIEWER
    }

    // Multi-Exam Selection
    fun toggleExam(exam: ExamCategoryId) {
        val current = _selectedExams.value.toMutableSet()
        if (current.contains(exam)) {
            if (current.size > 1) { // Keep at least one selected
                current.remove(exam)
            }
        } else {
            current.add(exam)
        }
        _selectedExams.value = current
        repository.saveSelectedExams(current)
    }

    fun selectAllExams() {
        val all = ExamCategoryId.entries.toSet()
        _selectedExams.value = all
        repository.saveSelectedExams(all)
    }

    fun selectSchoolAndJeeNeet() {
        val subset = setOf(
            ExamCategoryId.CLASS_10,
            ExamCategoryId.CLASS_11,
            ExamCategoryId.CLASS_12,
            ExamCategoryId.JEE_MAIN_ADV,
            ExamCategoryId.NEET_UG
        )
        _selectedExams.value = subset
        repository.saveSelectedExams(subset)
    }

    fun selectGovtExams() {
        val subset = setOf(
            ExamCategoryId.GOVT_SSC,
            ExamCategoryId.GOVT_UPSC,
            ExamCategoryId.GOVT_RAILWAY,
            ExamCategoryId.GOVT_BANKING,
            ExamCategoryId.GOVT_DEFENCE,
            ExamCategoryId.GOVT_TEACHING
        )
        _selectedExams.value = subset
        repository.saveSelectedExams(subset)
    }

    // Chapters
    fun toggleTheoryDone(chapterId: String) {
        val updated = _chapters.value.map {
            if (it.id == chapterId) it.copy(isTheoryDone = !it.isTheoryDone) else it
        }
        _chapters.value = updated
        repository.saveChapters(updated)
    }

    fun adjustPyqs(chapterId: String, delta: Int) {
        val updated = _chapters.value.map {
            if (it.id == chapterId) {
                val newCount = (it.pyqsCount + delta).coerceAtLeast(0)
                it.copy(pyqsCount = newCount)
            } else it
        }
        _chapters.value = updated
        repository.saveChapters(updated)
    }

    fun cycleRevision(chapterId: String) {
        val updated = _chapters.value.map {
            if (it.id == chapterId) {
                val nextRev = (it.revisionCount + 1) % 4 // 0, 1, 2, 3
                it.copy(revisionCount = nextRev)
            } else it
        }
        _chapters.value = updated
        repository.saveChapters(updated)
    }

    fun addCustomChapter(name: String, classLevel: String, subject: String, examCategory: ExamCategoryId) {
        val newChapter = ChapterItem(
            id = "custom_${System.currentTimeMillis()}",
            examCategory = examCategory.name,
            classLevel = classLevel,
            subject = subject,
            name = name
        )
        val updated = _chapters.value + newChapter
        _chapters.value = updated
        repository.saveChapters(updated)
    }

    fun updateChapter(chapter: ChapterItem) {
        val updated = _chapters.value.map { if (it.id == chapter.id) chapter else it }
        _chapters.value = updated
        repository.saveChapters(updated)
    }

    fun deleteChapter(chapterId: String) {
        val updated = _chapters.value.filter { it.id != chapterId }
        _chapters.value = updated
        repository.saveChapters(updated)
    }

    // Tasks
    fun addTask(text: String, priority: String) {
        if (text.isBlank()) return
        val newTask = StudyTask(
            id = System.currentTimeMillis(),
            text = text.trim(),
            isDone = false,
            priority = priority
        )
        val updated = listOf(newTask) + _tasks.value
        _tasks.value = updated
        repository.saveTasks(updated)
    }

    fun toggleTask(id: Long) {
        val updated = _tasks.value.map {
            if (it.id == id) it.copy(isDone = !it.isDone) else it
        }
        _tasks.value = updated
        repository.saveTasks(updated)
    }

    fun deleteTask(id: Long) {
        val updated = _tasks.value.filter { it.id != id }
        _tasks.value = updated
        repository.saveTasks(updated)
    }

    fun clearDoneTasks() {
        val updated = _tasks.value.filter { !it.isDone }
        _tasks.value = updated
        repository.saveTasks(updated)
    }

    // Notes
    fun addNote(title: String, subject: String, examTag: String, content: String) {
        if (title.isBlank() || content.isBlank()) return
        val newNote = FormulaNote(
            id = System.currentTimeMillis(),
            title = title.trim(),
            subject = subject.trim(),
            examTag = examTag.trim(),
            content = content.trim()
        )
        val updated = listOf(newNote) + _notes.value
        _notes.value = updated
        repository.saveNotes(updated)
    }

    fun deleteNote(id: Long) {
        val updated = _notes.value.filter { it.id != id }
        _notes.value = updated
        repository.saveNotes(updated)
    }

    // AI Doubt Solver
    fun sendAiMessage(promptText: String) {
        val text = promptText.trim()
        if (text.isBlank()) return

        val userMessage = AiMessage(
            id = System.currentTimeMillis(),
            role = "user",
            text = text,
            timestamp = System.currentTimeMillis()
        )
        _aiMessages.value = _aiMessages.value + userMessage
        _isAiThinking.value = true

        val activeExamNames = _selectedExams.value.joinToString(", ") { it.shortName }

        viewModelScope.launch {
            val answer = GeminiAiService.askGemini(text, activeExamNames)
            val modelMessage = AiMessage(
                id = System.currentTimeMillis(),
                role = "model",
                text = answer,
                timestamp = System.currentTimeMillis()
            )
            _aiMessages.value = _aiMessages.value + modelMessage
            _isAiThinking.value = false
        }
    }

    fun clearAiChat() {
        _aiMessages.value = listOf(
            AiMessage(
                id = System.currentTimeMillis(),
                role = "model",
                text = "Chat history cleared! Aapka agla doubt kya hai? 10th-12th, JEE, NEET ya Govt exam ke sawal poochhein.",
                timestamp = System.currentTimeMillis()
            )
        )
    }

    // Pomodoro Timer Controls
    fun setTimerDuration(minutes: Int) {
        pauseTimer()
        val totalSecs = minutes * 60
        _initialTimerSeconds.value = totalSecs
        _timerSeconds.value = totalSecs
    }

    fun toggleTimer() {
        if (_isTimerRunning.value) {
            pauseTimer()
        } else {
            startTimer()
        }
    }

    fun startTimer() {
        if (_isTimerRunning.value) return
        _isTimerRunning.value = true
        timerJob = viewModelScope.launch {
            while (_timerSeconds.value > 0 && _isTimerRunning.value) {
                delay(1000)
                _timerSeconds.value -= 1
                if (_timerSeconds.value % 60 == 0) {
                    _totalStudyMinutes.value += 1
                    repository.addStudyMinutes(1)
                }
            }
            if (_timerSeconds.value <= 0) {
                _isTimerRunning.value = false
            }
        }
    }

    fun pauseTimer() {
        _isTimerRunning.value = false
        timerJob?.cancel()
        timerJob = null
    }

    fun resetTimer() {
        pauseTimer()
        _timerSeconds.value = _initialTimerSeconds.value
    }

    // Motivational Shayari
    fun nextShayari() {
        val total = DefaultData.motivationalShayari.size
        _shayariIndex.value = (_shayariIndex.value + 1) % total
    }
}
