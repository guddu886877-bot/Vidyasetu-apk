package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.example.model.AiMessage
import com.example.model.ChapterItem
import com.example.model.ExamCategoryId
import com.example.model.FormulaNote
import com.example.model.StudyTask
import org.json.JSONArray
import org.json.JSONObject

class AppRepository(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("vidyasetu_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_SELECTED_EXAMS = "selected_exams"
        private const val KEY_CHAPTERS = "chapters_json"
        private const val KEY_TASKS = "tasks_json"
        private const val KEY_NOTES = "notes_json"
        private const val KEY_TOTAL_STUDY_MINUTES = "total_study_minutes"
    }

    // Selected Exams (Multi-select)
    fun getSelectedExams(): Set<ExamCategoryId> {
        val saved = prefs.getStringSet(KEY_SELECTED_EXAMS, null)
        return if (saved.isNullOrEmpty()) {
            // Default active exams: 10th, 12th, JEE, NEET, SSC
            setOf(
                ExamCategoryId.CLASS_10,
                ExamCategoryId.CLASS_12,
                ExamCategoryId.JEE_MAIN_ADV,
                ExamCategoryId.NEET_UG,
                ExamCategoryId.GOVT_SSC
            )
        } else {
            saved.mapNotNull {
                try {
                    ExamCategoryId.valueOf(it)
                } catch (e: Exception) {
                    null
                }
            }.toSet().ifEmpty {
                setOf(ExamCategoryId.CLASS_12, ExamCategoryId.NEET_UG)
            }
        }
    }

    fun saveSelectedExams(exams: Set<ExamCategoryId>) {
        val stringSet = exams.map { it.name }.toSet()
        prefs.edit().putStringSet(KEY_SELECTED_EXAMS, stringSet).apply()
    }

    // Chapters
    fun getChapters(): List<ChapterItem> {
        val jsonStr = prefs.getString(KEY_CHAPTERS, null)
        if (jsonStr.isNullOrBlank()) {
            return DefaultData.defaultChapters
        }
        return try {
            val array = JSONArray(jsonStr)
            val list = mutableListOf<ChapterItem>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    ChapterItem(
                        id = obj.getString("id"),
                        examCategory = obj.optString("examCategory", ExamCategoryId.NEET_UG.name),
                        classLevel = obj.optString("classLevel", "12"),
                        subject = obj.getString("subject"),
                        name = obj.getString("name"),
                        isTheoryDone = obj.optBoolean("isTheoryDone", false),
                        pyqsCount = obj.optInt("pyqsCount", 0),
                        revisionCount = obj.optInt("revisionCount", 0),
                        hasAttendedMock = obj.optBoolean("hasAttendedMock", false),
                        notes = obj.optString("notes", "")
                    )
                )
            }
            list
        } catch (e: Exception) {
            DefaultData.defaultChapters
        }
    }

    fun saveChapters(chapters: List<ChapterItem>) {
        try {
            val array = JSONArray()
            for (ch in chapters) {
                val obj = JSONObject().apply {
                    put("id", ch.id)
                    put("examCategory", ch.examCategory)
                    put("classLevel", ch.classLevel)
                    put("subject", ch.subject)
                    put("name", ch.name)
                    put("isTheoryDone", ch.isTheoryDone)
                    put("pyqsCount", ch.pyqsCount)
                    put("revisionCount", ch.revisionCount)
                    put("hasAttendedMock", ch.hasAttendedMock)
                    put("notes", ch.notes)
                }
                array.put(obj)
            }
            prefs.edit().putString(KEY_CHAPTERS, array.toString()).apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // Tasks / To-Do
    fun getTasks(): List<StudyTask> {
        val jsonStr = prefs.getString(KEY_TASKS, null)
        if (jsonStr.isNullOrBlank()) {
            return DefaultData.defaultTasks
        }
        return try {
            val array = JSONArray(jsonStr)
            val list = mutableListOf<StudyTask>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    StudyTask(
                        id = obj.getLong("id"),
                        text = obj.getString("text"),
                        isDone = obj.getBoolean("isDone"),
                        priority = obj.optString("priority", "MED")
                    )
                )
            }
            list
        } catch (e: Exception) {
            DefaultData.defaultTasks
        }
    }

    fun saveTasks(tasks: List<StudyTask>) {
        try {
            val array = JSONArray()
            for (t in tasks) {
                val obj = JSONObject().apply {
                    put("id", t.id)
                    put("text", t.text)
                    put("isDone", t.isDone)
                    put("priority", t.priority)
                }
                array.put(obj)
            }
            prefs.edit().putString(KEY_TASKS, array.toString()).apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // Notes
    fun getNotes(): List<FormulaNote> {
        val jsonStr = prefs.getString(KEY_NOTES, null)
        if (jsonStr.isNullOrBlank()) {
            return DefaultData.defaultNotes
        }
        return try {
            val array = JSONArray(jsonStr)
            val list = mutableListOf<FormulaNote>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    FormulaNote(
                        id = obj.getLong("id"),
                        title = obj.getString("title"),
                        subject = obj.getString("subject"),
                        examTag = obj.getString("examTag"),
                        content = obj.getString("content")
                    )
                )
            }
            list
        } catch (e: Exception) {
            DefaultData.defaultNotes
        }
    }

    fun saveNotes(notes: List<FormulaNote>) {
        try {
            val array = JSONArray()
            for (n in notes) {
                val obj = JSONObject().apply {
                    put("id", n.id)
                    put("title", n.title)
                    put("subject", n.subject)
                    put("examTag", n.examTag)
                    put("content", n.content)
                }
                array.put(obj)
            }
            prefs.edit().putString(KEY_NOTES, array.toString()).apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // Study minutes
    fun getTotalStudyMinutes(): Int = prefs.getInt(KEY_TOTAL_STUDY_MINUTES, 45)

    fun addStudyMinutes(minutes: Int) {
        val current = getTotalStudyMinutes()
        prefs.edit().putInt(KEY_TOTAL_STUDY_MINUTES, current + minutes).apply()
    }
}
