package com.example.data

import com.example.model.ChapterItem
import com.example.model.CoachingPlatform
import com.example.model.ExamCategoryId
import com.example.model.FormulaNote
import com.example.model.StudyTask

object DefaultData {

    val motivationalShayari = listOf(
        "ना पूछो कि मेरी मंजिल कहाँ है, अभी तो सफर का इरादा किया है, ना हारूंगा हौसला उम्र भर, ये मैंने किसी से नहीं खुद से वादा किया है।",
        "मेहनत इतनी खामोशी से करो कि तुम्हारी सफलता पूरे देश में शोर मचा दे!",
        "मंजिलें भी जिद्दी हैं, रास्ते भी जिद्दी हैं, देखते हैं कल क्या होगा, हमारे हौसले भी तो जिद्दी हैं!",
        "किताबों की दुनिया में जब खो जाओगे, यकीन मानो एक दिन सबसे बेहतरीन मुकाम पर पाओगे।",
        "रात भर जाग कर पढ़ना शुरू कर दो, क्योंकि किस्मत के सितारे तभी चमकेंगे जब मेहनत पूरी होगी।",
        "हार और जीत हमारी सोच पर निर्भर करती है, मान लो तो हार होगी और ठान लो तो जीत होगी!",
        "Biology की NCERT हो या Maths के कठिन सवाल, रोज अभ्यास करने वालों का ही होता है कमाल!",
        "संघर्ष में आदमी अकेला होता है, सफलता में दुनिया उसके साथ होती है। लग जाओ आज ही!",
        "जब टूटने लगे हौसला तो याद रखना, बिना मेहनत के तख्तो-ताज नहीं मिलते, जुगनू कभी रोशनी के मोहताज नहीं होते!",
        "सपना एक देखोगे मुश्किलें हजार आएंगी, लेकिन वो मंजर बड़ा खूबसूरत होगा जब कामयाबी शोर मचाएगी!"
    )

    val coachingPlatforms: List<CoachingPlatform> = listOf(
        CoachingPlatform(
            id = "pw",
            name = "Physics Wallah (PW)",
            tagline = "Padhlo Chahe Kahin Se, Selection Hoga Yahin Se!",
            founderOrBrand = "Alakh Pandey Sir",
            packageName = "xyz.penpencil.physicswala",
            webUrl = "https://www.pw.live",
            playStoreUrl = "https://play.google.com/store/apps/details?id=xyz.penpencil.physicswala",
            youtubeChannelUrl = "https://www.youtube.com/@PhysicsWallah",
            popularBatches = listOf("Arjuna 11th", "Lakshya 12th", "Yakeen NEET", "Prayas JEE", "Udaan 10th", "Parishram"),
            categoriesCovered = listOf(
                ExamCategoryId.CLASS_10,
                ExamCategoryId.CLASS_11,
                ExamCategoryId.CLASS_12,
                ExamCategoryId.JEE_MAIN_ADV,
                ExamCategoryId.NEET_UG,
                ExamCategoryId.GOVT_SSC,
                ExamCategoryId.GOVT_DEFENCE
            ),
            brandColorHex = 0xFF5A4BDA
        ),
        CoachingPlatform(
            id = "motion",
            name = "Motion Education",
            tagline = "Kota's Premier Coaching for JEE, NEET & Foundation",
            founderOrBrand = "Nitin Vijay (NV) Sir",
            packageName = "com.motion.motionlearning",
            altPackageName = "com.motion.app",
            webUrl = "https://motion.ac.in",
            playStoreUrl = "https://play.google.com/store/apps/details?id=com.motion.motionlearning",
            youtubeChannelUrl = "https://www.youtube.com/@MotionJEE",
            popularBatches = listOf("Drona Batch", "Brahmastra Crash Course", "Eklavya Kota Classroom", "Ambitious 10th"),
            categoriesCovered = listOf(
                ExamCategoryId.CLASS_10,
                ExamCategoryId.CLASS_11,
                ExamCategoryId.CLASS_12,
                ExamCategoryId.JEE_MAIN_ADV,
                ExamCategoryId.NEET_UG
            ),
            brandColorHex = 0xFFDC2626
        ),
        CoachingPlatform(
            id = "target_board",
            name = "Target Board",
            tagline = "State Board & 10th-12th Hindi Medium Topper Factory",
            founderOrBrand = "Prince Sir",
            packageName = "com.targetboard.app",
            webUrl = "https://targetboard.in",
            playStoreUrl = "https://play.google.com/store/apps/details?id=com.targetboard.app",
            youtubeChannelUrl = "https://www.youtube.com/@TargetBoard",
            popularBatches = listOf("Matric Topper Batch 10th", "Inter Board Topper 12th", "Science & Arts Crash Course", "Grammar Special"),
            categoriesCovered = listOf(
                ExamCategoryId.CLASS_10,
                ExamCategoryId.CLASS_11,
                ExamCategoryId.CLASS_12
            ),
            brandColorHex = 0xFF0D9488
        ),
        CoachingPlatform(
            id = "kgs",
            name = "Khan Global Studies (KGS)",
            tagline = "Affordable Quality Education for UPSC, BPSC & Govt Exams",
            founderOrBrand = "Khan Sir Patna",
            packageName = "xyz.penpencil.khansirofficial",
            altPackageName = "com.khanglobalstudies.app",
            webUrl = "https://khanglobalstudies.com",
            playStoreUrl = "https://play.google.com/store/apps/details?id=xyz.penpencil.khansirofficial",
            youtubeChannelUrl = "https://www.youtube.com/@khangsresearchcentre1685",
            popularBatches = listOf("UPSC CSE Foundation", "BPSC Special", "SSC CGL & CHSL", "Railway NTPC & Gr. D", "NDA & Defence", "Daroga / SI"),
            categoriesCovered = listOf(
                ExamCategoryId.GOVT_UPSC,
                ExamCategoryId.GOVT_SSC,
                ExamCategoryId.GOVT_RAILWAY,
                ExamCategoryId.GOVT_DEFENCE,
                ExamCategoryId.GOVT_TEACHING
            ),
            brandColorHex = 0xFF1E3A8A
        ),
        CoachingPlatform(
            id = "allen",
            name = "ALLEN Career Institute",
            tagline = "Kota's Benchmark for Top Ranks in JEE & NEET",
            founderOrBrand = "ALLEN Digital",
            packageName = "com.allen.digital",
            altPackageName = "com.allencareer.allen",
            webUrl = "https://allen.ac.in",
            playStoreUrl = "https://play.google.com/store/apps/details?id=com.allen.digital",
            youtubeChannelUrl = "https://www.youtube.com/@ALLENCareerInstituteofficial",
            popularBatches = listOf("Leader Batch (Dropper)", "Nurture 11th", "Enthusiast 12th", "ALLEN Online Test Series (OLTS)"),
            categoriesCovered = listOf(
                ExamCategoryId.CLASS_10,
                ExamCategoryId.CLASS_11,
                ExamCategoryId.CLASS_12,
                ExamCategoryId.JEE_MAIN_ADV,
                ExamCategoryId.NEET_UG
            ),
            brandColorHex = 0xFF0284C7
        ),
        CoachingPlatform(
            id = "adda247",
            name = "Adda247",
            tagline = "India's #1 Govt Job Exam Preparation Platform",
            founderOrBrand = "Adda247 Team",
            packageName = "com.adda247.app",
            webUrl = "https://www.adda247.com",
            playStoreUrl = "https://play.google.com/store/apps/details?id=com.adda247.app",
            youtubeChannelUrl = "https://www.youtube.com/@Adda247Official",
            popularBatches = listOf("SSC Mahapack", "Bank Mahapack", "Railway Special Batch", "Teaching CTET"),
            categoriesCovered = listOf(
                ExamCategoryId.GOVT_SSC,
                ExamCategoryId.GOVT_BANKING,
                ExamCategoryId.GOVT_RAILWAY,
                ExamCategoryId.GOVT_TEACHING
            ),
            brandColorHex = 0xFFEA580C
        ),
        CoachingPlatform(
            id = "testbook",
            name = "Testbook",
            tagline = "Best Mock Tests & Live Coaching for 700+ Govt Exams",
            founderOrBrand = "Testbook Team",
            packageName = "com.testbook.tbapp",
            webUrl = "https://testbook.com",
            playStoreUrl = "https://play.google.com/store/apps/details?id=com.testbook.tbapp",
            youtubeChannelUrl = "https://www.youtube.com/@TestbookSuperCoaching",
            popularBatches = listOf("Testbook Pass Pro", "SuperCoaching SSC", "Railway Complete Course", "State Exam Pass"),
            categoriesCovered = listOf(
                ExamCategoryId.GOVT_SSC,
                ExamCategoryId.GOVT_RAILWAY,
                ExamCategoryId.GOVT_BANKING,
                ExamCategoryId.GOVT_UPSC,
                ExamCategoryId.GOVT_DEFENCE
            ),
            brandColorHex = 0xFF059669
        ),
        CoachingPlatform(
            id = "unacademy",
            name = "Unacademy",
            tagline = "India's Largest Learning Platform",
            founderOrBrand = "Unacademy",
            packageName = "com.unacademyapp",
            webUrl = "https://unacademy.com",
            playStoreUrl = "https://play.google.com/store/apps/details?id=com.unacademyapp",
            youtubeChannelUrl = "https://www.youtube.com/@unacademy",
            popularBatches = listOf("Plus & Iconic", "JEE Super 30", "NEET All Stars", "UPSC CSE Abhiyaan"),
            categoriesCovered = listOf(
                ExamCategoryId.CLASS_10,
                ExamCategoryId.CLASS_11,
                ExamCategoryId.CLASS_12,
                ExamCategoryId.JEE_MAIN_ADV,
                ExamCategoryId.NEET_UG,
                ExamCategoryId.GOVT_UPSC
            ),
            brandColorHex = 0xFF10B981
        )
    )

    val defaultChapters: List<ChapterItem> = listOf(
        // CLASS 10
        ChapterItem("10_sci_1", ExamCategoryId.CLASS_10.name, "10", "Science", "Chemical Reactions and Equations"),
        ChapterItem("10_sci_2", ExamCategoryId.CLASS_10.name, "10", "Science", "Acids, Bases and Salts"),
        ChapterItem("10_sci_3", ExamCategoryId.CLASS_10.name, "10", "Science", "Metals and Non-metals"),
        ChapterItem("10_sci_4", ExamCategoryId.CLASS_10.name, "10", "Science", "Carbon and its Compounds"),
        ChapterItem("10_sci_5", ExamCategoryId.CLASS_10.name, "10", "Science", "Life Processes (Nutrition & Respiration)"),
        ChapterItem("10_sci_6", ExamCategoryId.CLASS_10.name, "10", "Science", "Control and Coordination"),
        ChapterItem("10_sci_7", ExamCategoryId.CLASS_10.name, "10", "Science", "How do Organisms Reproduce?"),
        ChapterItem("10_sci_8", ExamCategoryId.CLASS_10.name, "10", "Science", "Heredity and Evolution"),
        ChapterItem("10_sci_9", ExamCategoryId.CLASS_10.name, "10", "Science", "Light: Reflection and Refraction"),
        ChapterItem("10_sci_10", ExamCategoryId.CLASS_10.name, "10", "Science", "Human Eye and Colourful World"),
        ChapterItem("10_sci_11", ExamCategoryId.CLASS_10.name, "10", "Science", "Electricity & Ohm's Law"),
        ChapterItem("10_sci_12", ExamCategoryId.CLASS_10.name, "10", "Science", "Magnetic Effects of Electric Current"),
        ChapterItem("10_mat_1", ExamCategoryId.CLASS_10.name, "10", "Mathematics", "Real Numbers"),
        ChapterItem("10_mat_2", ExamCategoryId.CLASS_10.name, "10", "Mathematics", "Polynomials"),
        ChapterItem("10_mat_3", ExamCategoryId.CLASS_10.name, "10", "Mathematics", "Pair of Linear Equations in Two Variables"),
        ChapterItem("10_mat_4", ExamCategoryId.CLASS_10.name, "10", "Mathematics", "Quadratic Equations"),
        ChapterItem("10_mat_5", ExamCategoryId.CLASS_10.name, "10", "Mathematics", "Arithmetic Progressions (AP)"),
        ChapterItem("10_mat_6", ExamCategoryId.CLASS_10.name, "10", "Mathematics", "Triangles & Similarity"),
        ChapterItem("10_mat_7", ExamCategoryId.CLASS_10.name, "10", "Mathematics", "Coordinate Geometry"),
        ChapterItem("10_mat_8", ExamCategoryId.CLASS_10.name, "10", "Mathematics", "Introduction to Trigonometry & Heights"),
        ChapterItem("10_mat_9", ExamCategoryId.CLASS_10.name, "10", "Mathematics", "Circles"),
        ChapterItem("10_mat_10", ExamCategoryId.CLASS_10.name, "10", "Mathematics", "Surface Areas and Volumes"),
        ChapterItem("10_mat_11", ExamCategoryId.CLASS_10.name, "10", "Mathematics", "Statistics and Probability"),

        // CLASS 11 / JEE / NEET COMMON
        ChapterItem("11_phy_1", ExamCategoryId.CLASS_11.name, "11", "Physics", "Units and Measurements"),
        ChapterItem("11_phy_2", ExamCategoryId.CLASS_11.name, "11", "Physics", "Motion in a Straight Line"),
        ChapterItem("11_phy_3", ExamCategoryId.CLASS_11.name, "11", "Physics", "Motion in a Plane (Vectors & Projectile)"),
        ChapterItem("11_phy_4", ExamCategoryId.CLASS_11.name, "11", "Physics", "Laws of Motion (Newton's Laws & Friction)"),
        ChapterItem("11_phy_5", ExamCategoryId.CLASS_11.name, "11", "Physics", "Work, Energy and Power"),
        ChapterItem("11_phy_6", ExamCategoryId.CLASS_11.name, "11", "Physics", "Rotational Motion & Centre of Mass"),
        ChapterItem("11_phy_7", ExamCategoryId.CLASS_11.name, "11", "Physics", "Gravitation"),
        ChapterItem("11_phy_8", ExamCategoryId.CLASS_11.name, "11", "Physics", "Mechanical Properties of Solids & Fluids"),
        ChapterItem("11_phy_9", ExamCategoryId.CLASS_11.name, "11", "Physics", "Thermodynamics & Kinetic Theory"),
        ChapterItem("11_phy_10", ExamCategoryId.CLASS_11.name, "11", "Physics", "Oscillations (SHM) & Waves"),

        ChapterItem("11_chem_1", ExamCategoryId.CLASS_11.name, "11", "Chemistry", "Some Basic Concepts of Chemistry (Mole Concept)"),
        ChapterItem("11_chem_2", ExamCategoryId.CLASS_11.name, "11", "Chemistry", "Structure of Atom"),
        ChapterItem("11_chem_3", ExamCategoryId.CLASS_11.name, "11", "Chemistry", "Periodic Classification & Periodicity"),
        ChapterItem("11_chem_4", ExamCategoryId.CLASS_11.name, "11", "Chemistry", "Chemical Bonding and Molecular Structure"),
        ChapterItem("11_chem_5", ExamCategoryId.CLASS_11.name, "11", "Chemistry", "Chemical Thermodynamics"),
        ChapterItem("11_chem_6", ExamCategoryId.CLASS_11.name, "11", "Chemistry", "Equilibrium (Chemical & Ionic)"),
        ChapterItem("11_chem_7", ExamCategoryId.CLASS_11.name, "11", "Chemistry", "Redox Reactions"),
        ChapterItem("11_chem_8", ExamCategoryId.CLASS_11.name, "11", "Chemistry", "Organic Chemistry: Principles & Techniques (GOC)"),
        ChapterItem("11_chem_9", ExamCategoryId.CLASS_11.name, "11", "Chemistry", "Hydrocarbons (Alkanes, Alkenes, Alkynes)"),

        // CLASS 12 / JEE / NEET COMMON
        ChapterItem("12_phy_1", ExamCategoryId.CLASS_12.name, "12", "Physics", "Electric Charges and Fields"),
        ChapterItem("12_phy_2", ExamCategoryId.CLASS_12.name, "12", "Physics", "Electrostatic Potential and Capacitance"),
        ChapterItem("12_phy_3", ExamCategoryId.CLASS_12.name, "12", "Physics", "Current Electricity & Circuits"),
        ChapterItem("12_phy_4", ExamCategoryId.CLASS_12.name, "12", "Physics", "Moving Charges and Magnetism"),
        ChapterItem("12_phy_5", ExamCategoryId.CLASS_12.name, "12", "Physics", "Electromagnetic Induction & AC"),
        ChapterItem("12_phy_6", ExamCategoryId.CLASS_12.name, "12", "Physics", "Ray Optics and Optical Instruments"),
        ChapterItem("12_phy_7", ExamCategoryId.CLASS_12.name, "12", "Physics", "Wave Optics"),
        ChapterItem("12_phy_8", ExamCategoryId.CLASS_12.name, "12", "Physics", "Dual Nature of Radiation & Matter"),
        ChapterItem("12_phy_9", ExamCategoryId.CLASS_12.name, "12", "Physics", "Atoms & Nuclei"),
        ChapterItem("12_phy_10", ExamCategoryId.CLASS_12.name, "12", "Physics", "Semiconductor Electronics"),

        ChapterItem("12_chem_1", ExamCategoryId.CLASS_12.name, "12", "Chemistry", "Solutions"),
        ChapterItem("12_chem_2", ExamCategoryId.CLASS_12.name, "12", "Chemistry", "Electrochemistry"),
        ChapterItem("12_chem_3", ExamCategoryId.CLASS_12.name, "12", "Chemistry", "Chemical Kinetics"),
        ChapterItem("12_chem_4", ExamCategoryId.CLASS_12.name, "12", "Chemistry", "d- and f-Block Elements & Coordination Compounds"),
        ChapterItem("12_chem_5", ExamCategoryId.CLASS_12.name, "12", "Chemistry", "Haloalkanes and Haloarenes"),
        ChapterItem("12_chem_6", ExamCategoryId.CLASS_12.name, "12", "Chemistry", "Alcohols, Phenols and Ethers"),
        ChapterItem("12_chem_7", ExamCategoryId.CLASS_12.name, "12", "Chemistry", "Aldehydes, Ketones and Carboxylic Acids"),
        ChapterItem("12_chem_8", ExamCategoryId.CLASS_12.name, "12", "Chemistry", "Amines & Biomolecules"),

        // NEET BIOLOGY SPECIFIC
        ChapterItem("neet_bio_1", ExamCategoryId.NEET_UG.name, "11", "Biology", "Living World & Biological Classification"),
        ChapterItem("neet_bio_2", ExamCategoryId.NEET_UG.name, "11", "Biology", "Plant & Animal Kingdom"),
        ChapterItem("neet_bio_3", ExamCategoryId.NEET_UG.name, "11", "Biology", "Morphology & Anatomy of Flowering Plants"),
        ChapterItem("neet_bio_4", ExamCategoryId.NEET_UG.name, "11", "Biology", "Cell: The Unit of Life & Cell Cycle"),
        ChapterItem("neet_bio_5", ExamCategoryId.NEET_UG.name, "11", "Biology", "Biomolecules (NCERT Line-by-Line)"),
        ChapterItem("neet_bio_6", ExamCategoryId.NEET_UG.name, "11", "Biology", "Plant Physiology (Photosynthesis & Respiration)"),
        ChapterItem("neet_bio_7", ExamCategoryId.NEET_UG.name, "11", "Biology", "Human Physiology (Circulation, Excretion, Neural)"),
        ChapterItem("neet_bio_8", ExamCategoryId.NEET_UG.name, "12", "Biology", "Sexual Reproduction in Flowering Plants"),
        ChapterItem("neet_bio_9", ExamCategoryId.NEET_UG.name, "12", "Biology", "Human Reproduction & Reproductive Health"),
        ChapterItem("neet_bio_10", ExamCategoryId.NEET_UG.name, "12", "Biology", "Genetics: Inheritance & Molecular Basis"),
        ChapterItem("neet_bio_11", ExamCategoryId.NEET_UG.name, "12", "Biology", "Evolution & Human Health and Disease"),
        ChapterItem("neet_bio_12", ExamCategoryId.NEET_UG.name, "12", "Biology", "Biotechnology: Principles & Applications"),
        ChapterItem("neet_bio_13", ExamCategoryId.NEET_UG.name, "12", "Biology", "Ecology & Environmental Biology"),

        // JEE MATHEMATICS SPECIFIC
        ChapterItem("jee_mat_1", ExamCategoryId.JEE_MAIN_ADV.name, "11", "Mathematics", "Sets, Relations & Functions"),
        ChapterItem("jee_mat_2", ExamCategoryId.JEE_MAIN_ADV.name, "11", "Mathematics", "Complex Numbers & Quadratic Equations"),
        ChapterItem("jee_mat_3", ExamCategoryId.JEE_MAIN_ADV.name, "11", "Mathematics", "Permutations and Combinations (P&C)"),
        ChapterItem("jee_mat_4", ExamCategoryId.JEE_MAIN_ADV.name, "11", "Mathematics", "Binomial Theorem & Sequences/Series"),
        ChapterItem("jee_mat_5", ExamCategoryId.JEE_MAIN_ADV.name, "11", "Mathematics", "Straight Lines & Conic Sections (Parabola, Ellipse, Hyperbola)"),
        ChapterItem("jee_mat_6", ExamCategoryId.JEE_MAIN_ADV.name, "12", "Mathematics", "Matrices & Determinants"),
        ChapterItem("jee_mat_7", ExamCategoryId.JEE_MAIN_ADV.name, "12", "Mathematics", "Limits, Continuity & Differentiability"),
        ChapterItem("jee_mat_8", ExamCategoryId.JEE_MAIN_ADV.name, "12", "Mathematics", "Application of Derivatives (AOD)"),
        ChapterItem("jee_mat_9", ExamCategoryId.JEE_MAIN_ADV.name, "12", "Mathematics", "Definite & Indefinite Integration"),
        ChapterItem("jee_mat_10", ExamCategoryId.JEE_MAIN_ADV.name, "12", "Mathematics", "Differential Equations & Vectors 3D Geometry"),

        // GOVERNMENT EXAMS (SSC / RAILWAY / DEFENCE / BANKING / UPSC)
        ChapterItem("govt_qa_1", ExamCategoryId.GOVT_SSC.name, "All", "Quantitative Aptitude", "Percentages, Profit & Loss, Discount"),
        ChapterItem("govt_qa_2", ExamCategoryId.GOVT_SSC.name, "All", "Quantitative Aptitude", "Ratio & Proportion, Mixture & Allegation"),
        ChapterItem("govt_qa_3", ExamCategoryId.GOVT_SSC.name, "All", "Quantitative Aptitude", "Time, Speed, Distance & Trains"),
        ChapterItem("govt_qa_4", ExamCategoryId.GOVT_SSC.name, "All", "Quantitative Aptitude", "Time & Work, Pipes & Cisterns"),
        ChapterItem("govt_qa_5", ExamCategoryId.GOVT_SSC.name, "All", "Quantitative Aptitude", "Simple & Compound Interest (SI/CI)"),
        ChapterItem("govt_qa_6", ExamCategoryId.GOVT_SSC.name, "All", "Quantitative Aptitude", "Algebra, Trigonometry & Geometry"),
        ChapterItem("govt_lr_1", ExamCategoryId.GOVT_SSC.name, "All", "Reasoning", "Coding-Decoding & Blood Relations"),
        ChapterItem("govt_lr_2", ExamCategoryId.GOVT_SSC.name, "All", "Reasoning", "Syllogism, Venn Diagrams & Direction Sense"),
        ChapterItem("govt_lr_3", ExamCategoryId.GOVT_SSC.name, "All", "Reasoning", "Seating Arrangement & Puzzles"),
        ChapterItem("govt_ga_1", ExamCategoryId.GOVT_SSC.name, "All", "General Awareness", "Indian Constitution & Polity (Articles & Amendments)"),
        ChapterItem("govt_ga_2", ExamCategoryId.GOVT_SSC.name, "All", "General Awareness", "Modern Indian History & Freedom Struggle"),
        ChapterItem("govt_ga_3", ExamCategoryId.GOVT_SSC.name, "All", "General Awareness", "General Science (Physics, Chemistry, Biology PYQs)"),
        ChapterItem("govt_ga_4", ExamCategoryId.GOVT_SSC.name, "All", "General Awareness", "Indian Geography & River Systems"),
        ChapterItem("govt_ga_5", ExamCategoryId.GOVT_SSC.name, "All", "General Awareness", "Current Affairs & Static GK (Schemes, Awards, Sports)"),

        // UPSC SPECIAL
        ChapterItem("upsc_1", ExamCategoryId.GOVT_UPSC.name, "All", "GS Paper 1", "Ancient, Medieval & Modern Indian History & Art and Culture"),
        ChapterItem("upsc_2", ExamCategoryId.GOVT_UPSC.name, "All", "GS Paper 1", "Physical & Human Geography (India & World)"),
        ChapterItem("upsc_3", ExamCategoryId.GOVT_UPSC.name, "All", "GS Paper 2", "Indian Polity, Governance, Constitution & Judiciary"),
        ChapterItem("upsc_4", ExamCategoryId.GOVT_UPSC.name, "All", "GS Paper 3", "Indian Economy, Agriculture, Science & Tech, Environment"),
        ChapterItem("upsc_5", ExamCategoryId.GOVT_UPSC.name, "All", "CSAT", "Reading Comprehension, Analytical Ability & Basic Numeracy")
    )

    val defaultTasks: List<StudyTask> = listOf(
        StudyTask(1, "Modern Physics / Optics ke 40 PYQs lagane hain", false, "HIGH"),
        StudyTask(2, "Maths / Quant: Percentage & Profit-Loss formula revision", false, "HIGH"),
        StudyTask(3, "Organic Chemistry / Science: Named Reactions revise karna", true, "MED"),
        StudyTask(4, "Khan Sir / PW lecture ke short notes complete karna", false, "MED")
    )

    val defaultNotes: List<FormulaNote> = listOf(
        FormulaNote(
            id = 1,
            title = "Photoelectric Effect Equations",
            subject = "Physics",
            examTag = "NEET / JEE",
            content = "E = hν = φ + KE_max\nStopping Potential: V_0 = (hν - φ) / e\nde-Broglie wavelength: λ = h / p = h / √(2mE)"
        ),
        FormulaNote(
            id = 2,
            title = "Quadratic Equations Quick Roots",
            subject = "Mathematics",
            examTag = "10th / JEE",
            content = "For ax² + bx + c = 0:\nSum of roots: α + β = -b/a\nProduct of roots: αβ = c/a\nDiscriminant D = b² - 4ac (Real if D ≥ 0)"
        ),
        FormulaNote(
            id = 3,
            title = "Important Articles of Indian Constitution",
            subject = "Polity",
            examTag = "Govt SSC / UPSC",
            content = "Art 14: Equality before law\nArt 21: Right to Life & Personal Liberty\nArt 32: Constitutional Remedies (Heart & Soul)\nArt 324: Election Commission"
        ),
        FormulaNote(
            id = 4,
            title = "Hardy-Weinberg Equilibrium",
            subject = "Biology",
            examTag = "NEET",
            content = "p² + 2pq + q² = 1\np = frequency of dominant allele\nq = frequency of recessive allele\np + q = 1"
        )
    )
}
