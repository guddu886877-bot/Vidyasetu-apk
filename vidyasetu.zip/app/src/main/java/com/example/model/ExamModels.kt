package com.example.model

enum class ExamCategoryId(
    val title: String,
    val shortName: String,
    val subtitle: String,
    val badgeColorHex: Long
) {
    CLASS_10("Class 10th (Board)", "10th", "Maths, Science, SST, Hindi, Eng", 0xFF0284C7),
    CLASS_11("Class 11th (Science)", "11th", "Physics, Chemistry, Maths, Bio", 0xFF059669),
    CLASS_12("Class 12th (Boards)", "12th", "Physics, Chemistry, Maths, Bio", 0xFF10B981),
    JEE_MAIN_ADV("JEE (Main & Advanced)", "JEE", "Physics, Chemistry, Mathematics", 0xFFF59E0B),
    NEET_UG("NEET (UG Medical)", "NEET", "Physics, Chemistry, Biology (360/360)", 0xFF10B981),
    GOVT_SSC("SSC (CGL, CHSL, MTS)", "SSC", "Quant, Reasoning, English, GA", 0xFF8B5CF6),
    GOVT_UPSC("UPSC & State PCS", "UPSC", "Polity, History, Geo, Economy, CSAT", 0xFFEC4899),
    GOVT_RAILWAY("Railway (RRB NTPC)", "Railway", "General Science, Maths, GK/GS", 0xFFF97316),
    GOVT_BANKING("Banking (IBPS, SBI)", "Banking", "Aptitude, Reasoning, Financial", 0xFF3B82F6),
    GOVT_DEFENCE("Defence (NDA, CDS)", "Defence", "Maths, GAT, English, Police", 0xFF14B8A6),
    GOVT_TEACHING("Teaching (CTET/TET)", "Teaching", "Child Pedagogy, Language, Maths", 0xFFA855F7);

    companion object {
        fun fromId(id: String): ExamCategoryId {
            return entries.find { it.name == id } ?: NEET_UG
        }
    }
}

data class ChapterItem(
    val id: String,
    val examCategory: String, // ExamCategoryId.name
    val classLevel: String,   // "10", "11", "12", "All"
    val subject: String,
    val name: String,
    val isTheoryDone: Boolean = false,
    val pyqsCount: Int = 0,
    val revisionCount: Int = 0,
    val hasAttendedMock: Boolean = false,
    val notes: String = ""
)

data class CoachingPlatform(
    val id: String,
    val name: String,
    val tagline: String,
    val founderOrBrand: String,
    val packageName: String,
    val altPackageName: String? = null,
    val webUrl: String,
    val playStoreUrl: String,
    val youtubeChannelUrl: String,
    val popularBatches: List<String>,
    val categoriesCovered: List<ExamCategoryId>,
    val brandColorHex: Long
)

data class StudyTask(
    val id: Long = System.currentTimeMillis(),
    val text: String,
    val isDone: Boolean = false,
    val priority: String = "MED" // HIGH, MED, LOW
)

data class FormulaNote(
    val id: Long = System.currentTimeMillis(),
    val title: String,
    val subject: String,
    val examTag: String,
    val content: String
)

data class AiMessage(
    val id: Long = System.currentTimeMillis(),
    val role: String, // "user" or "model"
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isGenerating: Boolean = false
)
